from fastapi import FastAPI
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from chatbot import responder_com_memoria

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

class Pergunta(BaseModel):
    pergunta: str

@app.post("/chat")
async def responder(pergunta: Pergunta):
    resposta = responder_com_memoria(pergunta.pergunta)
    return {"resposta": resposta}
