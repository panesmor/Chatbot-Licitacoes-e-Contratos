import streamlit as st
import requests

st.set_page_config(page_title="Chatbot de Atendimento",
                   page_icon="⚡", layout="centered")

st.image("https://upload.wikimedia.org/wikipedia/commons/thumb/4/4e/Cemig_logo.svg/2560px-Cemig_logo.svg.png", width=200)

st.title("⚡ Chatbot Cemig para Licitações e Contratos")
st.markdown(
    "Converse com o assistente virtual para tirar dúvidas e obter suporte sobre Licitações e Contratos.")

# Estilos
st.markdown("""
<style>
.chat-bubble {
    padding: 10px;
    border-radius: 10px;
    margin: 5px 0;
}
.user {
    background-color: #FFCC00;
    text-align: right;
    padding: 10px;
    border-radius: 10px;
}
.bot {
    background-color: #006633;
    color: white;
    text-align: left;
    padding: 10px;
    border-radius: 10px;
}
</style>
""", unsafe_allow_html=True)

# Estado da sessão
if "historico" not in st.session_state:
    st.session_state["historico"] = []
if "nova_pergunta" not in st.session_state:
    st.session_state["nova_pergunta"] = False
if "pergunta_temp" not in st.session_state:
    st.session_state["pergunta_temp"] = ""

# Função para obter resposta


def obter_resposta_do_chatbot(pergunta_usuario):
    url = "http://127.0.0.1:8000/chat"
    try:
        response = requests.post(url, json={"pergunta": pergunta_usuario})
        if response.status_code == 200:
            return response.json().get("resposta", "Erro: resposta vazia.")
        else:
            return f"Erro ao chamar o chatbot: código {response.status_code}"
    except Exception as e:
        return f"Erro de conexão: {e}"


# Campo de pergunta sempre visível
with st.form(key="form_pergunta", clear_on_submit=True):
    pergunta = st.text_input("Digite sua pergunta:")
    enviar = st.form_submit_button("Enviar")
    if enviar and pergunta.strip():
        st.session_state["pergunta_temp"] = pergunta
        st.session_state["nova_pergunta"] = True

# Processa nova pergunta
if st.session_state["nova_pergunta"]:
    pergunta = st.session_state["pergunta_temp"]
    resposta = obter_resposta_do_chatbot(pergunta)
    st.session_state["historico"].append(("Você", pergunta))
    st.session_state["historico"].append(("Chatbot", resposta))
    st.session_state["nova_pergunta"] = False

# Exibe histórico em ordem reversa (últimas mensagens no topo)
for remetente, mensagem in reversed(st.session_state["historico"]):
    classe = "user" if remetente == "Você" else "bot"
    st.markdown(
        f"<div class='chat-bubble {classe}'>{remetente}: {mensagem}</div>", unsafe_allow_html=True)

# Botão para limpar conversa
if st.button("🧹 Limpar conversa"):
    st.session_state["historico"] = []
    st.rerun()
