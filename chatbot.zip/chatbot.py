import os
import docx
import pandas as pd
import pdfplumber
from pptx import Presentation
from pathlib import Path

from langchain_openai import ChatOpenAI
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import PromptTemplate
from langchain_core.documents import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS

from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_core.chat_history import InMemoryChatMessageHistory

# Caminhos
caminho_para_salvar = Path("vectorstore")
os.makedirs(caminho_para_salvar, exist_ok=True)
caminho_pasta = "C:/Users/User/Documents/Especializacao PLN/chatbot_cemig/documentos"

# Funções de leitura de arquivos


def read_txt(path):
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        print(f"Erro ao ler TXT {path}: {e}")
        return ""


def read_pdf(path):
    try:
        with pdfplumber.open(path) as pdf:
            return "\n".join(p.extract_text() or "" for p in pdf.pages)
    except Exception as e:
        print(f"Erro ao ler PDF {path}: {e}")
        return ""


def read_pptx(path):
    try:
        prs = Presentation(path)
        return "\n".join(shape.text for slide in prs.slides for shape in slide.shapes if hasattr(shape, "text"))
    except Exception as e:
        print(f"Erro ao ler PPTX {path}: {e}")
        return ""


def read_csv(path):
    try:
        return pd.read_csv(path).to_string()
    except Exception as e:
        print(f"Erro ao ler CSV {path}: {e}")
        return ""


def read_word_file(path):
    try:
        ext = os.path.splitext(path)[1].lower()
        if ext == '.docx':
            return "\n".join(p.text for p in docx.Document(path).paragraphs)
        else:
            return ""
    except Exception as e:
        print(f"Erro ao ler Word {path}: {e}")
        return ""


def carregar_documentos_do_diretorio(caminho_diretorio):
    documentos = []
    for nome_arquivo in os.listdir(caminho_diretorio):
        if nome_arquivo.startswith("~") or nome_arquivo.startswith("."):
            continue
        caminho_completo = os.path.join(caminho_diretorio, nome_arquivo)
        conteudo = ""
        if nome_arquivo.endswith(".txt"):
            conteudo = read_txt(caminho_completo)
        elif nome_arquivo.endswith(".pdf"):
            conteudo = read_pdf(caminho_completo)
        elif nome_arquivo.endswith(".pptx"):
            conteudo = read_pptx(caminho_completo)
        elif nome_arquivo.endswith(".csv"):
            conteudo = read_csv(caminho_completo)
        elif nome_arquivo.endswith((".docx", ".doc")):
            conteudo = read_word_file(caminho_completo)

        if conteudo:
            documentos.append(Document(page_content=conteudo,
                              metadata={"fonte": nome_arquivo}))
    return documentos


# Inicializa embeddings
embedding_function = HuggingFaceEmbeddings(
    model_name="intfloat/multilingual-e5-large")

# Verifica se o vector store já existe
faiss_index = caminho_para_salvar / "index.faiss"
faiss_pkl = caminho_para_salvar / "index.pkl"

if faiss_index.exists() and faiss_pkl.exists():
    db = FAISS.load_local(str(caminho_para_salvar),
                          embeddings=embedding_function, allow_dangerous_deserialization=True)
else:
    documentos_carregados = carregar_documentos_do_diretorio(caminho_pasta)
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=800, chunk_overlap=160)
    chunks = splitter.split_documents(documentos_carregados)
    db = FAISS.from_documents(chunks, embedding_function)
    db.save_local(str(caminho_para_salvar))

# Prompt com histórico
template_prompt = """
### Histórico da Conversa:
{chat_history}

### Instruções:
Você é um assistente pessoal da CEMIG responsável por responder perguntas dos usuários, com base no contexto fornecido.
Procure responder o mais próximo possível do contexto abordado na pergunta do usuário.
Caso o contexto de resposta seja muito amplo, faça nova pergunta ao usuário para obter mais detalhes e refinar a pesquisa.
Ao final, pergunte se o usuário deseja obter mais informações sobre o assunto.
A cada nova pergunta do usuário verifique o contexto da conversa para avaliar a resposta, considerando assuntos já tratados anteriormente
Sempre que possível, cite a fonte da sua informação no final da resposta, como por exemplo: (Fonte: nome_do_arquivo).

### Documentos:
{context}

### Pergunta:
{query}

### Resposta:
"""
prompt = PromptTemplate(
    input_variables=["chat_history", "context", "query"], template=template_prompt)

# Configura LLM
# Substitua pela sua chave real
os.environ["OPENAI_API_KEY"] = "Sua Chave OpenAI"
llm_gpt = ChatOpenAI(model="gpt-4o-mini")

# Função para formatar documentos


def formatar_documentos(docs):
    return "\n\n".join(f"Fonte: {doc.metadata['fonte']}\nConteúdo: {doc.page_content}" for doc in docs)


retriever = db.as_retriever(search_kwargs={'k': 10})

# Pipeline RAG


rag_gpt = (
    {
        "context": lambda x: formatar_documentos(retriever.invoke(x["query"])),
        "query": lambda x: x["query"],
        "chat_history": lambda x: x.get("chat_history", "")
    }
    | prompt
    | llm_gpt
    | StrOutputParser()
)

# Função para obter histórico por sessão


def get_session_history(session_id: str) -> InMemoryChatMessageHistory:
    return InMemoryChatMessageHistory()


# Pipeline com memória
rag_gpt_com_memoria = RunnableWithMessageHistory(
    rag_gpt,
    get_session_history,
    input_messages_key="query",
    history_messages_key="chat_history"
)

# Função para responder com memória


def responder_com_memoria(pergunta, session_id="default"):
    if isinstance(pergunta, dict):
        pergunta_texto = pergunta.get("pergunta", "")
    else:
        pergunta_texto = str(pergunta)


# Recupera histórico da sessão
    chat_history = get_session_history(session_id).messages

    resposta = rag_gpt_com_memoria.invoke(
        {
            "query": pergunta_texto,
            "chat_history": chat_history
        },
        config={"configurable": {"session_id": session_id}}
    )
    return resposta
